# -*- coding: utf-8 -*-
"""
Created on Thu Mar 28 19:51:52 2019

@author: 30523
"""

import numpy as np
import random
a = np.array([[1,2,3],[4,6,6],[1,2,3]])
b=[1,2,5]
a[1]=b

print(type(b))
print(a.shape)
print(type(a))
print(a)
